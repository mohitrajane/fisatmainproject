fisatproject - FISAT Main Project Template
==========================================

This is a template for use in main project report (KTU Batch). 

A tex file is given as a reference. Make changes to that tex file only. Inorder to get the tex file working you need to put all the files here in same folder. Requirements for getting this template working is

 - TeXlive 
 - Packages geometry, graphicx, url, titlesec, appendix, listings installed

If you are running TeXlive full, then these packages are installed by default. Otherwise you need to manually install them. 
